﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;
using System.IO;
using System.Windows;

namespace websiteShortcuts
{
    public partial class Form1 : Form
    {

        public int count;
        public int websiteCount = 1;
        public string folder = Environment.CurrentDirectory + @"\websiteFiles";
        public string theFile = Environment.CurrentDirectory + @"\websiteFiles\";
        string websiteFile = Environment.CurrentDirectory + @"\websiteFiles\websites.txt";
        public string daFile;
        public int counting = 1;
        int newSize = 11;
        public string name;
        public string[] names;
        public int items;
        public bool deleteClicked;
        public bool renameClicked;
        Process pro = new Process();
        int w = 300;
        public bool formMoved;

        public Form1()
        {
            
            InitializeComponent(); 
            if (!Directory.Exists(folder))
            {
               Directory.CreateDirectory(folder);
            }
            if(Properties.Settings.Default.hidePanelForGood == true)
            {
                panel1.Hide();
                Properties.Settings.Default.hidePanelForGood = true;
                Properties.Settings.Default.Save();
            }
            else
            {
                panel1.Show();
                Properties.Settings.Default.hidePanelForGood = false;
                Properties.Settings.Default.Save();
            }
            if(Properties.Settings.Default.backColor != null)
            {
                this.BackColor = Properties.Settings.Default.backColor;
            }
            ReadWebsites(theFile, flowLayoutPanel1);
            Screen[] screens = Screen.AllScreens;
            Screen screen = Screen.FromControl(this);
            int leftover = screen.WorkingArea.Width - this.Width;
            int formSize = screen.WorkingArea.Width - leftover;
            Properties.Settings.Default.tempWidth = formSize;
           
            Properties.Settings.Default.formStartPos = this.Location;
            Properties.Settings.Default.backColor = this.BackColor;

            Properties.Settings.Default.Save();

            this.Width = Properties.Settings.Default.tempWidth;

            this.Height = 245;
            hideBtn.Top = 225;
        }

        //add website button click
        private void button1_Click(object sender, EventArgs e)
        {
            CreateIcon(txtBoxWebsite.Text, flowLayoutPanel1);
            SaveWebsite(txtBoxWebsite.Text);
            txtBoxWebsite.Clear();
        }



        //My FUNCTIONS
        //Save Websites To Text File
        public void SaveWebsite(string url)
        {
            if (Directory.Exists(folder))
            {
                if (!File.Exists(theFile + url + ".txt"))
                {
                    string websiteLine = url;
                    // File.Delete(theFile);
                    try
                    {
                        File.Create(theFile + websiteLine + ".txt");
                        return;
                    } catch (Exception eee)
                    {
                        return;
                    }
                }
                else
                {
                    string websiteLine = url;
                    try
                    {
                        File.Create(theFile + websiteLine + ".txt");
                        return;
                    } catch (Exception ee)
                    {
                        return;
                    }
                }
            }
            else
            {
                Directory.CreateDirectory(folder);
                if (!File.Exists(theFile))
                {
                    string websiteLine = url;
                    // File.Delete(theFile);
                    try
                    {
                        File.Create(theFile + websiteLine + ".txt");
                        return;
                    } catch (Exception ef)
                    {
                        return;
                    }
                }
                else
                {
                    string websiteLine = url;
                    try
                    {
                        File.Create(theFile + websiteLine + ".txt");
                        return;
                    } catch (Exception es)
                    {
                        return;
                    }
                }
            }








        }

        //Create Icon For Website by Stripping www. and .com from the name and creating a button dynamically
        public void CreateIcon(string url, Control flowPanel)
        {
            //strip www and .com from url to use as the button text
            string[] name = url.Split('.');
            int newSize = 11;
            Button btn = new Button();
            btn.Text = name[1];
            btn.Name = url;
            btn.Tag = Path.GetFileName(theFile + url);
            btn.Width = 100;
            btn.Height = 50;

            btn.BackColor = Color.Black;
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Popup;
            btn.Padding.All.Equals(30);
            btn.Font = new Font(btn.Font.FontFamily, newSize);
            btn.MouseHover += new EventHandler(this.btn_MouseHover);
            btn.MouseEnter += new EventHandler(this.btn_MouseEnter);
            btn.MouseLeave += new EventHandler(this.btn_MouseLeave);
            btn.MouseDown += new MouseEventHandler(this.btn_MouseDown);
            btn.MouseClick += new MouseEventHandler(this.btn_MouseClick);



            btn.ContextMenuStrip = contextMenuStrip1;



            contextMenuStrip1.Click += new EventHandler(contextMenuStrip1_Click_1);



            flowPanel.Controls.Add(btn);

        }


        //read websites on startup
        public void ReadWebsites(string url, Control flowPanel)
        {
            string[] websites = Directory.GetFiles(theFile);

            foreach (string website in websites)
            {
                names = Path.GetFileNameWithoutExtension(website).Split('.');
                Button btn = new Button();
                btn.Text = names[1];
                btn.Name = Path.GetFileNameWithoutExtension(website);
                btn.Tag = Path.GetFileName(website);
                btn.Width = 100;
                btn.Height = 50;
                btn.BackColor = Color.Black;
                btn.ForeColor = Color.White;
                btn.FlatStyle = FlatStyle.Popup;
                btn.Padding.All.Equals(30);
                btn.Font = new Font(btn.Font.FontFamily, newSize);
                btn.MouseHover += new EventHandler(this.btn_MouseHover);
                btn.MouseEnter += new EventHandler(this.btn_MouseEnter);
                btn.MouseLeave += new EventHandler(this.btn_MouseLeave);
                btn.MouseDown += new MouseEventHandler(this.btn_MouseDown);
                btn.MouseClick += new MouseEventHandler(this.btn_MouseClick);


                btn.ContextMenuStrip = contextMenuStrip1;







                contextMenuStrip1.Click += new EventHandler(this.contextMenuStrip1_Click_1);



                flowPanel.Controls.Add(btn);
            }
        }


        //EVENTS
        //Mouse Button Events
        public void btn_MouseHover(object sender, EventArgs mea)
        {

        }

        public void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
        }

        public void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.Black;
            btn.ForeColor = Color.White;
        }

        public void btn_MouseDown(object sender, MouseEventArgs e)
        {
            Button btn = sender as Button;
            btn.BackColor = Color.Gray;
            btn.ForeColor = Color.Black;
        }

        public void btn_MouseClick(object sender, MouseEventArgs e)
        {
            Control activeBtn = sender as Button;
            if (e.Button == MouseButtons.Left)
            {
                Process.Start("https://" + activeBtn.Name.ToString());
                return;
            } else if (e.Button == MouseButtons.Right)
            {

            }
        }

        public void contextMenuStrip1_Click(object sender, EventArgs e)
        {

        }



        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public bool form2isOpen;
        private void contextMenuStrip1_Click_1(object sender, EventArgs e)
        {
            ContextMenuStrip cm = sender as ContextMenuStrip;
            Control sc;
            var s = sc = cm.SourceControl;
            if (deleteClicked == true)
            {
                deleteClicked = true;
                renameClicked = false;
                File.Delete(theFile + s.Tag.ToString());
                flowLayoutPanel1.Controls.Remove(s);
                deleteClicked = false;
                return;
            }
            else if (renameClicked == true)
            {

            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  renameClicked = false;
            // deleteClicked = true;
        }

        private void renameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  deleteClicked = false;
            //  renameClicked = true;
        }

        private void deleteToolStripMenuItem_MouseDown(object sender, MouseEventArgs e)
        {
            deleteClicked = true;
            renameClicked = false;
        }
        public TextBox txtBox = new TextBox();
        private void renameToolStripMenuItem_MouseDown(object sender, MouseEventArgs e)
        {
            renameClicked = true;
            deleteClicked = false;
            Form newForm = new Form();


            newForm.Width = 120;
            newForm.Height = 65;
            newForm.Name = "renameForm";
            newForm.Controls.Add(txtBox);
            txtBox.Padding.All.Equals(50);
            Button renameBtn = new Button();
            newForm.Controls.Add(renameBtn);
            renameBtn.Text = "Rename";
            
            renameBtn.Name = "rBtn";
            renameBtn.Height = 35;
            renameBtn.Width = 60;
            newForm.StartPosition = FormStartPosition.CenterScreen;
            newForm.FormBorderStyle = FormBorderStyle.None;
            renameBtn.Left = 130;
            renameBtn.Top = 15;
            txtBox.Left = 20;
            txtBox.Top = 20;
            txtBox.Name = "txtBoxRenew";


            newForm.Show();
            renameBtn.Click += new EventHandler(this.renameBtn_Click);

        }

        private void renameBtn_Click(object sender, EventArgs e)
        {
            Button rbtn = sender as Button;


            //MessageBox.Show(rbtn.Parent.);
            //close dynamic form

            rbtn.FindForm().Dispose();
        }

        private void RenameDynamicBtn(object sender, Control c, string newName)
        {
            Button btn = sender as Button;
            c = btn;
            c.Text = newName;
            MessageBox.Show(this.Controls.Contains(c).ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (this.Height != 30)
            {
                this.Height = 30;
                hideBtn.Top = 0;
                // btnStick.Top = 30;
                // btnUnstick.Top = 30;
                hideBtn.Text = "v";
                button1.Visible = false;
                txtBoxWebsite.Visible = false;
                button3.Visible = false;

            } else if (this.Height > 0)
            {
                this.Height = 245;
                hideBtn.Bottom.Equals(0);
                //  btnStick.Top = 7;
                //  btnUnstick.Top = 7;
                hideBtn.Top = 225;
                hideBtn.Text = "^";
                button1.Visible = true;
                txtBoxWebsite.Visible = true;
                
                    button3.Visible = true;
                if(this.Width > Properties.Settings.Default.tempWidth)
                {
                    button3.Visible = false;
                }
            }



        }

        private void hideBtn_MouseClick(object sender, MouseEventArgs e)
        {



        }

        private void btnStick_Click(object sender, EventArgs e)
        {

            Screen[] screens = Screen.AllScreens;
            Screen screen = Screen.FromControl(this);
            this.Top = screen.WorkingArea.Top;
            this.Left = screen.WorkingArea.Left;
            this.Width = screen.WorkingArea.Width;
            button3.Visible = false;

        }

        private void btnUnstick_Click(object sender, EventArgs e)
        {
            this.Width = Properties.Settings.Default.tempWidth;
            this.Location = Properties.Settings.Default.formStartPos;
            this.Location = Properties.Settings.Default.formStartPos;
            this.Location = Properties.Settings.Default.formStartPos;
            this.Location = Properties.Settings.Default.formStartPos;
            button3.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        private void button3_Click(object sender, EventArgs e)
        {

       
        }

        private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void Form1_Move(object sender, EventArgs e)
        {
           
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog() == DialogResult.OK)
            {
                this.BackColor = colorDialog1.Color;
            }
            else
            {
                return;
            }
            colorDialog1.Dispose();
            return;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.backColor = this.BackColor;

            Properties.Settings.Default.Save();
        }

        private void informationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void informationToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Information i = new Information();
            i.Show();
        }

        private void flowLayoutPanel1_MouseClick(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                contextMenuStrip2.Show();
            }
            else
            {
                return;
            }
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Point p = new Point(MousePosition.X, MousePosition.Y);
            if(e.Button == MouseButtons.Right)
            {
                contextMenuStrip2.Show();
            }
            else { return; }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.hidePanelForGood = false;
            Properties.Settings.Default.Save();
            panel1.Hide();
        }
        //hide for good
        private void button6_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.hidePanelForGood = true;
            panel1.Hide();
            Properties.Settings.Default.Save();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel1.Show();
            Properties.Settings.Default.hidePanelForGood = false;
            Properties.Settings.Default.Save();
        }
    }
}
